<script setup>
import { computed, ref } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Plus, Delete } from '@element-plus/icons-vue'
import BatchAddSourceDialog from './BatchAddSourceDialog.vue'

const route = useRoute()

const poolInfo = computed(() => ({
  name: String(route.query.poolName ?? '拨测池A1'),
  region: String(route.query.region ?? '华东'),
  creator: String(route.query.creator ?? '张三'),
  updatedAt: String(route.query.updatedAt ?? '2026-03-05')
}))

const keyword = ref('')

const batchAddVisible = ref(false)
const sources = ref([
  { id: 1, name: '物理机001', ip: '192.168.1.1', adder: '张三', addedAt: '2026-02-13', status: '在线' },
  { id: 2, name: '物理机002', ip: '192.168.1.2', adder: '李四', addedAt: '2026-02-27', status: '离线' },
  { id: 3, name: '物理机003', ip: '192.168.1.3', adder: '王五', addedAt: '2026-02-09', status: '在线' },
  { id: 4, name: '物理机004', ip: '192.168.1.4', adder: '赵六', addedAt: '2026-02-14', status: '在线' },
  { id: 5, name: '物理机005', ip: '192.168.1.5', adder: '钱七', addedAt: '2026-02-28', status: '在线' },
  { id: 6, name: '物理机006', ip: '192.168.1.6', adder: '张三', addedAt: '2026-02-15', status: '在线' },
  { id: 7, name: '物理机007', ip: '192.168.1.7', adder: '李四', addedAt: '2026-02-16', status: '离线' },
  { id: 8, name: '物理机008', ip: '192.168.1.8', adder: '王五', addedAt: '2026-02-17', status: '在线' },
  { id: 9, name: '物理机009', ip: '192.168.1.9', adder: '赵六', addedAt: '2026-02-18', status: '在线' },
  { id: 10, name: '物理机010', ip: '192.168.1.10', adder: '钱七', addedAt: '2026-02-19', status: '在线' }
])

const ipOptions = computed(() =>
  sources.value.map((s) => ({
    ip: s.ip,
    name: s.name
  }))
)

const filtered = computed(() => {
  const k = keyword.value.trim()
  if (!k) return sources.value
  return sources.value.filter((s) => s.name.includes(k) || s.ip.includes(k) || s.adder.includes(k))
})

const page = ref(1)
const pageSize = ref(5)
const total = computed(() => filtered.value.length)
const pageData = computed(() => {
  const start = (page.value - 1) * pageSize.value
  return filtered.value.slice(start, start + pageSize.value)
})

const selection = ref([])
function onSelectionChange(rows) {
  selection.value = rows
}
const selectedCount = computed(() => selection.value.length)

function onSearch() {
  page.value = 1
}

function onBatchAdd() {
  batchAddVisible.value = true
}

function onBatchAddSubmit(ips) {
  const existed = new Set(sources.value.map((s) => s.ip))
  const optionMap = new Map(ipOptions.value.map((o) => [o.ip, o.name]))

  const today = new Date()
  const yyyy = String(today.getFullYear())
  const mm = String(today.getMonth() + 1).padStart(2, '0')
  const dd = String(today.getDate()).padStart(2, '0')
  const addedAt = `${yyyy}-${mm}-${dd}`

  let added = 0
  for (const ip of ips) {
    if (existed.has(ip)) continue
    const name = optionMap.get(ip) ?? `物理机${String(sources.value.length + 1).padStart(3, '0')}`
    const id = sources.value.length ? Math.max(...sources.value.map((s) => s.id)) + 1 : 1
    sources.value.unshift({
      id,
      name,
      ip,
      adder: '当前用户',
      addedAt,
      status: '在线'
    })
    existed.add(ip)
    added += 1
  }
  ElMessage.success(added ? `已添加 ${added} 条` : '未新增（已存在）')
  page.value = 1
}

async function onBatchDelete() {
  if (!selectedCount.value) return
  try {
    await ElMessageBox.confirm(`确定批量删除 ${selectedCount.value} 条拨测源吗？`, '提示', {
      type: 'warning',
      confirmButtonText: '删除',
      cancelButtonText: '取消'
    })
    const ids = new Set(selection.value.map((r) => r.id))
    sources.value = sources.value.filter((s) => !ids.has(s.id))
    selection.value = []
    ElMessage.success('已删除')
    if ((page.value - 1) * pageSize.value >= total.value && page.value > 1) page.value -= 1
  } catch (_) {}
}

async function onDelete(row) {
  try {
    await ElMessageBox.confirm(`确定删除“${row.name}”吗？`, '提示', {
      type: 'warning',
      confirmButtonText: '删除',
      cancelButtonText: '取消'
    })
    sources.value = sources.value.filter((s) => s.id !== row.id)
    ElMessage.success('已删除')
    if ((page.value - 1) * pageSize.value >= total.value && page.value > 1) page.value -= 1
  } catch (_) {}
}
</script>

<template>
  <div class="page">
    <el-card shadow="never" class="info-card">
      <div class="info-title">拨测池信息</div>
      <div class="info-grid">
        <div class="info-item">
          <div class="k">拨测池名称：</div>
          <div class="v">{{ poolInfo.name }}</div>
        </div>
        <div class="info-item">
          <div class="k">所属区域：</div>
          <div class="v">{{ poolInfo.region }}</div>
        </div>
        <div class="info-item">
          <div class="k">创建人：</div>
          <div class="v">{{ poolInfo.creator }}</div>
        </div>
        <div class="info-item">
          <div class="k">修改时间：</div>
          <div class="v">{{ poolInfo.updatedAt }}</div>
        </div>
      </div>
    </el-card>

    <el-card shadow="never" class="table-card">
      <div class="toolbar">
        <div class="left">
          <el-input v-model="keyword" placeholder="关键字搜索（物理机名称/IP/添加人）" clearable style="width: 340px" />
          <el-button type="primary" @click="onSearch">
            <el-icon><Search /></el-icon>
            查询
          </el-button>
        </div>
        <div class="right">
          <el-button type="primary" @click="onBatchAdd">
            <el-icon><Plus /></el-icon>
            批量添加拨测源
          </el-button>
          <el-button :disabled="!selectedCount" @click="onBatchDelete">
            <el-icon><Delete /></el-icon>
            批量删除拨测源({{ selectedCount }})
          </el-button>
        </div>
      </div>

      <el-table :data="pageData" stripe style="width: 100%" @selection-change="onSelectionChange">
        <el-table-column type="selection" width="48" />
        <el-table-column prop="name" label="物理机名称" min-width="160" sortable />
        <el-table-column prop="ip" label="物理机IP" min-width="160" sortable />
        <el-table-column prop="adder" label="添加人" min-width="120" />
        <el-table-column prop="addedAt" label="添加时间" min-width="130" sortable />
        <el-table-column label="状态" min-width="100" align="center">
          <template #default="{ row }">
            <span class="status" :class="row.status === '在线' ? 'ok' : 'bad'">{{ row.status }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" min-width="140" align="center" fixed="right">
          <template #default="{ row }">
            <el-button size="small" type="danger" plain @click="onDelete(row)">
              <el-icon><Delete /></el-icon>
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination">
        <div class="total">共 {{ total }} 条</div>
        <el-pagination
          v-model:current-page="page"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[5, 10, 20, 50]"
          layout="sizes, prev, pager, next, jumper"
          background
        />
      </div>
    </el-card>

    <BatchAddSourceDialog v-model="batchAddVisible" :options="ipOptions" @submit="onBatchAddSubmit" />
  </div>
</template>

<style scoped>
.page {
  padding: 16px;
}
.info-card {
  margin-bottom: 12px;
}

.info-title {
  font-weight: 600;
  color: var(--el-text-color-primary);
  margin-bottom: 10px;
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 16px;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 28px;
}

.k {
  color: var(--el-text-color-regular);
}

.v {
  color: var(--el-text-color-primary);
  font-weight: 500;
}

.table-card {
  padding-bottom: 4px;
}

.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
}

.left,
.right {
  display: flex;
  align-items: center;
  gap: 10px;
}

.toolbar .el-icon {
  margin-right: 4px;
}

.status {
  font-weight: 600;
}

.status.ok {
  color: var(--el-color-success);
}

.status.bad {
  color: var(--el-color-danger);
}

.pagination {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 12px;
}

.total {
  color: var(--el-text-color-regular);
  font-size: 13px;
}

@media (max-width: 1100px) {
  .info-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
</style>

