<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { CircleCheck } from '@element-plus/icons-vue'

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  poolOptions: { type: Array, default: () => [] }
})

const emit = defineEmits(['update:modelValue', 'submit'])

const methodOptions = [
  { label: 'ping', value: 'ping' },
  { label: 'tcp', value: 'tcp' },
  { label: 'http/https', value: 'http/https' }
]

// 目标对象类型
const targetTypeOptions = [
  { label: 'IP/主机', value: 'ip' },
  { label: 'HTTP(S) 地址', value: 'url' }
]

// 目标对象候选（可按需从接口或 props 传入）
const targetOptions = ref([
  { label: '192.168.1.1', value: '192.168.1.1', type: 'ip' },
  { label: '192.168.1.2', value: '192.168.1.2', type: 'ip' },
  { label: 'http://example.com', value: 'http://example.com', type: 'url' },
  { label: 'https://api.example.com', value: 'https://api.example.com', type: 'url' }
])

const filteredTargetOptions = computed(() => {
  const t = form.targetType
  if (!t) return targetOptions.value
  return targetOptions.value.filter((opt) => opt.type === t)
})

const formRef = ref(null)
const form = reactive({
  pool: '',
  method: '',
  targetType: '',
  targetValue: '',
  port: '',
  cron: '',
  timeoutMs: 5000,
  retry: 0
})

const rules = {
  pool: [{ required: true, message: '请选择拨测池', trigger: 'change' }],
  method: [{ required: true, message: '请选择拨测方式', trigger: 'change' }],
  targetType: [{ required: true, message: '请选择对象类型', trigger: 'change' }],
  targetValue: [{ required: true, message: '请选择或输入目标对象', trigger: ['blur', 'change'] }],
  cron: [{ required: true, message: '请输入拨测频率', trigger: 'blur' }],
  timeoutMs: [{ required: true, message: '请输入超时时间', trigger: 'blur' }],
  retry: [{ required: true, message: '请输入重试次数', trigger: 'blur' }]
}

function close() {
  emit('update:modelValue', false)
}

function reset() {
  form.pool = ''
  form.method = ''
  form.targetType = ''
  form.targetValue = ''
  form.port = ''
  form.cron = ''
  form.timeoutMs = 5000
  form.retry = 0
  formRef?.clearValidate?.()
}

/** 根据目标类型、目标值、端口组合为后端使用的 target 字符串 */
function buildTargetString() {
  const v = (form.targetValue || '').trim()
  if (!v) return ''
  if (form.targetType === 'url') return v
  const p = (form.port || '').trim()
  return p ? `${v}:${p}` : v
}

watch(
  () => props.modelValue,
  (v) => {
    if (v) reset()
  }
)

watch(
  () => form.targetType,
  () => {
    form.targetValue = ''
  }
)

async function onConfirm() {
  const ok = await formRef?.validate?.().catch(() => false)
  if (!ok) return
  emit('submit', {
    pool: form.pool,
    method: form.method,
    target: buildTargetString(),
    cron: form.cron.trim(),
    timeoutMs: Number(form.timeoutMs) || 5000,
    retry: Number(form.retry) || 0
  })
  close()
}

async function onTest() {
  const ok = await formRef?.validate?.().catch(() => false)
  if (!ok) return
  ElMessage.info('连通性测试（示例未实现）')
}
</script>

<template>
  <el-dialog
    :model-value="modelValue"
    title="新增拨测规则"
    width="560px"
    align-center
    :close-on-click-modal="false"
    @update:model-value="(v) => emit('update:modelValue', v)"
  >
    <el-form ref="formRef" :model="form" :rules="rules" label-position="top" class="dlg-form">
      <el-form-item label="拨测池" prop="pool" required>
        <el-select v-model="form.pool" placeholder="选择拨测池" style="width: 100%">
          <el-option
            v-for="opt in poolOptions"
            :key="opt.value ?? opt"
            :label="opt.label ?? opt"
            :value="opt.value ?? opt"
          />
        </el-select>
      </el-form-item>

      <el-form-item label="拨测方式" prop="method" required>
        <el-select v-model="form.method" placeholder="选择拨测方式" style="width: 100%">
          <el-option v-for="opt in methodOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
        </el-select>
      </el-form-item>

      <el-form-item label="目标对象" required class="target-object-row">
        <div class="target-object-fields">
          <el-form-item prop="targetType" class="target-type-field">
            <el-select
              v-model="form.targetType"
              placeholder="选择对象类型"
              style="width: 100%"
              clearable
            >
              <el-option
                v-for="opt in targetTypeOptions"
                :key="opt.value"
                :label="opt.label"
                :value="opt.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item prop="targetValue" class="target-value-field">
            <el-select
              v-model="form.targetValue"
              placeholder="选择目标对象"
              filterable
              allow-create
              default-first-option
              style="width: 100%"
              clearable
            >
              <el-option
                v-for="opt in filteredTargetOptions"
                :key="opt.value"
                :label="opt.label"
                :value="opt.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item prop="port" class="port-field">
            <el-input
              v-model="form.port"
              placeholder="端口"
              clearable
            />
          </el-form-item>
        </div>
      </el-form-item>

      <el-form-item label="拨测频率 (Cron表达式)" prop="cron" required>
        <el-input v-model="form.cron" placeholder="如: */5 * * * *" clearable />
      </el-form-item>

      <el-form-item label="超时时间(ms)" prop="timeoutMs" required>
        <el-input-number v-model="form.timeoutMs" :min="1" :max="300000" :step="1000" style="width: 100%" />
      </el-form-item>

      <el-form-item label="重试次数" prop="retry" required>
        <el-input-number v-model="form.retry" :min="0" :max="10" style="width: 100%" />
      </el-form-item>
    </el-form>

    <template #footer>
      <div class="dlg-footer">
        <div class="dlg-footer-left">
          <el-button @click="onTest">
            <el-icon><CircleCheck /></el-icon>
            连通性测试
          </el-button>
        </div>
        <div class="dlg-footer-right">
          <el-button @click="close">取消</el-button>
          <el-button type="primary" @click="onConfirm">确定</el-button>
        </div>
      </div>
    </template>
  </el-dialog>
</template>

<style scoped>
.dlg-form {
  padding: 6px 0 0;
}

.dlg-form :deep(.el-form-item) {
  margin-bottom: 18px;
}

.target-object-row :deep(.el-form-item__content) {
  display: block;
}

.target-object-fields {
  display: flex;
  align-items: flex-start;
  gap: 12px;
}

.target-object-fields .target-type-field {
  flex: 0 0 120px;
  margin-bottom: 0;
}

.target-object-fields .target-value-field {
  flex: 1;
  min-width: 0;
  margin-bottom: 0;
}

.target-object-fields .port-field {
  flex: 0 0 100px;
  margin-bottom: 0;
}

.dlg-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  gap: 12px;
}

.dlg-footer-left {
  margin-right: auto;
}

.dlg-footer-right {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-left: auto;
}

.dlg-footer-left .el-icon {
  margin-right: 4px;
}
</style>
