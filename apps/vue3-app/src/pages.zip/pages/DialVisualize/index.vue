<script setup>
import { onMounted, onUnmounted, ref } from 'vue'
import { Plus, FullScreen } from '@element-plus/icons-vue'
import * as echarts from 'echarts'

const ruleOptions = [
  { label: '拨测池A1', value: '拨测池A1' },
  { label: '拨测池B2', value: '拨测池B2' },
  { label: '拨测池C3', value: '拨测池C3' }
]

const poolOptions = [
  { label: '选择拨测池', value: '' },
  { label: '拨测池A1', value: '拨测池A1' },
  { label: '拨测池B2', value: '拨测池B2' }
]

const sourceOptions = [
  { label: '选择拨测源', value: '' },
  { label: '物理机001', value: '物理机001' },
  { label: '物理机002', value: '物理机002' },
  { label: '物理机003', value: '物理机003' }
]

const ruleFilter = ref('拨测池A1')
const poolFilter = ref('')
const sourceFilter = ref('')
const dateRange = ref([])

function onSearch() {
  // 查询时刷新图表数据（示例仅用本地 mock）
  successChartRef.value && updateSuccessChart()
  responseChartRef.value && updateResponseChart()
}

const times = ['11:28', '13:28', '15:28', '17:28', '19:28', '21:28', '23:28', '01:28', '03:28', '05:28', '07:28', '10:28']

const successData = {
  物理机001: [1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1],
  物理机002: [1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1],
  物理机003: [1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1]
}

const responseData = {
  物理机001: [120, 280, 180, 320, 450, 380, 520, 150, 400, 350, 480, 550],
  物理机002: [80, 200, 350, 100, 280, 420, 380, 300, 180, 450, 90, 400],
  物理机003: [50, 380, 120, 450, 200, 320, 280, 400, 150, 300, 500, 250]
}

const successChartRef = ref(null)
const responseChartRef = ref(null)
let successChart = null
let responseChart = null

function updateSuccessChart() {
  if (!successChart || !successChartRef.value) return
  successChart.setOption({
    title: { text: '拨测成功情况折线图', left: 'center', top: 8, textStyle: { fontSize: 14 } },
    tooltip: { trigger: 'axis' },
    legend: { bottom: 8, data: ['物理机001', '物理机002', '物理机003'] },
    grid: { left: 48, right: 24, top: 40, bottom: 44 },
    xAxis: { type: 'category', data: times, boundaryGap: false },
    yAxis: {
      type: 'value',
      min: 0,
      max: 1,
      axisLabel: { formatter: (v) => (v === 1 ? '成功' : v === 0 ? '失败' : '') },
      splitLine: { show: false }
    },
    series: [
      { name: '物理机001', type: 'line', smooth: true, symbol: 'circle', data: successData['物理机001'], itemStyle: { color: '#5470c6' } },
      { name: '物理机002', type: 'line', smooth: true, symbol: 'circle', data: successData['物理机002'], itemStyle: { color: '#91cc75' } },
      { name: '物理机003', type: 'line', smooth: true, symbol: 'circle', data: successData['物理机003'], itemStyle: { color: '#fac858' } }
    ]
  })
}

function updateResponseChart() {
  if (!responseChart || !responseChartRef.value) return
  responseChart.setOption({
    title: { text: '拨测响应情况折线图', left: 'center', top: 8, textStyle: { fontSize: 14 } },
    tooltip: { trigger: 'axis' },
    legend: { bottom: 8, data: ['物理机001', '物理机002', '物理机003'] },
    grid: { left: 48, right: 24, top: 40, bottom: 44 },
    xAxis: { type: 'category', data: times, boundaryGap: false },
    yAxis: { type: 'value', min: 0, max: 600, interval: 150 },
    series: [
      { name: '物理机001', type: 'line', smooth: true, symbol: 'circle', data: responseData['物理机001'], itemStyle: { color: '#5470c6' } },
      { name: '物理机002', type: 'line', smooth: true, symbol: 'circle', data: responseData['物理机002'], itemStyle: { color: '#91cc75' } },
      { name: '物理机003', type: 'line', smooth: true, symbol: 'circle', data: responseData['物理机003'], itemStyle: { color: '#fac858' } }
    ]
  })
}

function zoomChart(which) {
  if (which === 'success') successChart?.resize()
  else if (which === 'response') responseChart?.resize()
}

const resizeHandler = () => {
  successChart?.resize()
  responseChart?.resize()
}

onMounted(() => {
  if (successChartRef.value) {
    successChart = echarts.init(successChartRef.value)
    updateSuccessChart()
  }
  if (responseChartRef.value) {
    responseChart = echarts.init(responseChartRef.value)
    updateResponseChart()
  }
  window.addEventListener('resize', resizeHandler)
})

onUnmounted(() => {
  window.removeEventListener('resize', resizeHandler)
  successChart?.dispose()
  responseChart?.dispose()
})
</script>

<template>
  <div class="page">
    <el-card shadow="never" class="filter-card">
      <div class="filter-row">
        <span class="filter-label">拨测规则</span>
        <el-select v-model="ruleFilter" placeholder="拨测规则" style="width: 160px">
          <el-option v-for="opt in ruleOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
        </el-select>
        <span class="filter-label">拨测池</span>
        <el-select v-model="poolFilter" placeholder="选择拨测池" style="width: 160px">
          <el-option v-for="opt in poolOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
        </el-select>
        <span class="filter-label">拨测源</span>
        <el-select v-model="sourceFilter" placeholder="选择拨测源" style="width: 160px">
          <el-option v-for="opt in sourceOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
        </el-select>
        <span class="filter-label">时间筛选</span>
        <el-date-picker
          v-model="dateRange"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          value-format="YYYY-MM-DD"
          style="width: 260px"
        />
      </div>
      <div class="filter-row">
        <el-button type="primary" @click="onSearch">
          <el-icon><Plus /></el-icon>
          查询
        </el-button>
      </div>
    </el-card>

    <div class="charts">
      <el-card shadow="never" class="chart-card">
        <div class="chart-header">
          <span class="chart-title">拨测成功情况折线图</span>
          <el-button type="primary" size="small" @click="zoomChart('success')">
            <el-icon><FullScreen /></el-icon>
            放大
          </el-button>
        </div>
        <div ref="successChartRef" class="chart-inner"></div>
      </el-card>
      <el-card shadow="never" class="chart-card">
        <div class="chart-header">
          <span class="chart-title">拨测响应情况折线图</span>
          <el-button type="primary" size="small" @click="zoomChart('response')">
            <el-icon><FullScreen /></el-icon>
            放大
          </el-button>
        </div>
        <div ref="responseChartRef" class="chart-inner"></div>
      </el-card>
    </div>
  </div>
</template>

<style scoped>
.page {
  padding: 16px;
}

.filter-card {
  margin-bottom: 12px;
}

.filter-row {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 10px;
}

.filter-row:last-child {
  margin-bottom: 0;
}

.filter-label {
  color: var(--el-text-color-regular);
  font-size: 14px;
  white-space: nowrap;
}

.filter-row .el-icon,
.chart-header .el-icon {
  margin-right: 4px;
}

.charts {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.chart-card {
  min-height: 360px;
}

.chart-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.chart-title {
  font-weight: 600;
  font-size: 14px;
  color: var(--el-text-color-primary);
}

.chart-inner {
  width: 100%;
  height: 320px;
}

@media (max-width: 900px) {
  .charts {
    grid-template-columns: 1fr;
  }
}
</style>
