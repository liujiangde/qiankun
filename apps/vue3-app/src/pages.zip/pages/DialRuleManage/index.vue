<script setup>
import { computed, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Download, Upload, EditPen, Delete } from '@element-plus/icons-vue'
import CreateRuleDialog from './CreateRuleDialog.vue'

const poolOptions = [
  { label: '拨测池A1', value: '拨测池A1' },
  { label: '拨测池B2', value: '拨测池B2' },
  { label: '拨测池C3', value: '拨测池C3' },
  { label: '拨测池D4', value: '拨测池D4' },
  { label: '拨测池E5', value: '拨测池E5' }
]

const methodOptions = [
  { label: '全部', value: '' },
  { label: 'ping', value: 'ping' },
  { label: 'tcp', value: 'tcp' },
  { label: 'http/https', value: 'http/https' }
]

const statusFilterOptions = [
  { label: '全部', value: '' },
  { label: '运行中', value: '运行中' },
  { label: '已停止', value: '已停止' }
]

const keyword = ref('')
const methodFilter = ref('')
const statusFilter = ref('')

const rules = ref([
  { id: 1, pool: '拨测池A1', method: 'ping', target: '192.168.1.1:8080', cron: '* /5 * * * *', timeout: '20秒', retry: 3, creator: '张三', updatedAt: '2026-02-15', status: '已停止' },
  { id: 2, pool: '拨测池B2', method: 'tcp', target: 'http://example.com', cron: '* /10 * * * *', timeout: '5秒', retry: 1, creator: '李四', updatedAt: '2026-02-26', status: '运行中' },
  { id: 3, pool: '拨测池C3', method: 'http/https', target: '192.168.1.2:3306', cron: '0 * * * *', timeout: '6秒', retry: 2, creator: '王五', updatedAt: '2026-02-09', status: '已停止' },
  { id: 4, pool: '拨测池D4', method: 'ping', target: 'http://test.com/api', cron: '0 0 * * *', timeout: '24秒', retry: 3, creator: '赵六', updatedAt: '2026-02-14', status: '运行中' },
  { id: 5, pool: '拨测池E5', method: 'tcp', target: '192.168.1.3:22', cron: '* /15 * * * *', timeout: '10秒', retry: 2, creator: '钱七', updatedAt: '2026-02-20', status: '已停止' },
  { id: 6, pool: '拨测池A1', method: 'http/https', target: '192.168.1.4:80', cron: '* /5 * * * *', timeout: '15秒', retry: 1, creator: '张三', updatedAt: '2026-02-16', status: '运行中' },
  { id: 7, pool: '拨测池B2', method: 'ping', target: 'https://api.example.com', cron: '0 */2 * * *', timeout: '8秒', retry: 3, creator: '李四', updatedAt: '2026-02-22', status: '已停止' },
  { id: 8, pool: '拨测池C3', method: 'tcp', target: '192.168.1.5:443', cron: '* /30 * * * *', timeout: '12秒', retry: 2, creator: '王五', updatedAt: '2026-02-18', status: '运行中' },
  { id: 9, pool: '拨测池D4', method: 'ping', target: '192.168.1.6:22', cron: '0 0 * * *', timeout: '5秒', retry: 1, creator: '赵六', updatedAt: '2026-02-24', status: '已停止' },
  { id: 10, pool: '拨测池E5', method: 'http/https', target: 'http://demo.com', cron: '* /10 * * * *', timeout: '20秒', retry: 2, creator: '钱七', updatedAt: '2026-02-28', status: '运行中' },
  { id: 11, pool: '拨测池A1', method: 'tcp', target: '192.168.1.7:3306', cron: '0 * * * *', timeout: '6秒', retry: 3, creator: '张三', updatedAt: '2026-03-01', status: '已停止' },
  { id: 12, pool: '拨测池B2', method: 'ping', target: '192.168.1.8:8080', cron: '* /5 * * * *', timeout: '10秒', retry: 1, creator: '李四', updatedAt: '2026-02-27', status: '运行中' },
  { id: 13, pool: '拨测池C3', method: 'http/https', target: 'https://test.org', cron: '* /15 * * * *', timeout: '18秒', retry: 2, creator: '王五', updatedAt: '2026-02-19', status: '已停止' },
  { id: 14, pool: '拨测池D4', method: 'ping', target: '192.168.1.9:80', cron: '0 0 * * *', timeout: '5秒', retry: 1, creator: '赵六', updatedAt: '2026-02-25', status: '运行中' },
  { id: 15, pool: '拨测池E5', method: 'tcp', target: '192.168.1.10:22', cron: '* /20 * * * *', timeout: '12秒', retry: 2, creator: '钱七', updatedAt: '2026-03-02', status: '已停止' }
])

const filtered = computed(() => {
  const k = keyword.value.trim()
  const list = rules.value.filter((r) => {
    const okMethod = !methodFilter.value || r.method === methodFilter.value
    const okStatus = !statusFilter.value || r.status === statusFilter.value
    const okKeyword = !k || r.pool.includes(k) || r.target.includes(k) || r.creator.includes(k)
    return okMethod && okStatus && okKeyword
  })
  return list
})

const page = ref(1)
const pageSize = ref(5)
const total = computed(() => filtered.value.length)
const pageData = computed(() => {
  const start = (page.value - 1) * pageSize.value
  return filtered.value.slice(start, start + pageSize.value)
})

const selection = ref([])
function onSelectionChange(rows) {
  selection.value = rows
}

function onSearch() {
  page.value = 1
}

function methodTagType(method) {
  if (method === 'ping') return 'primary'
  if (method === 'tcp') return 'success'
  if (method === 'http/https') return 'warning'
  return 'info'
}

function onStart(row) {
  row.status = '运行中'
  ElMessage.success('已启动')
}

function onStop(row) {
  row.status = '已停止'
  ElMessage.success('已停止')
}

function onEdit(row) {
  ElMessage.info(`编辑规则：${row.pool} - ${row.target}（示例未实现）`)
}

async function onDelete(row) {
  try {
    await ElMessageBox.confirm(`确定删除该拨测规则吗？`, '提示', {
      type: 'warning',
      confirmButtonText: '删除',
      cancelButtonText: '取消'
    })
    rules.value = rules.value.filter((r) => r.id !== row.id)
    ElMessage.success('已删除')
    if ((page.value - 1) * pageSize.value >= total.value && page.value > 1) page.value -= 1
  } catch (_) {}
}

function onExport(row) {
  ElMessage.success(`导出规则：${row.pool}（示例未实现）`)
}

const createVisible = ref(false)
function onCreate() {
  createVisible.value = true
}

function onCreateSubmit(payload) {
  const today = new Date()
  const yyyy = String(today.getFullYear())
  const mm = String(today.getMonth() + 1).padStart(2, '0')
  const dd = String(today.getDate()).padStart(2, '0')
  const updatedAt = `${yyyy}-${mm}-${dd}`
  const timeoutStr = payload.timeoutMs >= 1000 ? `${Math.round(payload.timeoutMs / 1000)}秒` : `${payload.timeoutMs}ms`
  const id = rules.value.length ? Math.max(...rules.value.map((r) => r.id)) + 1 : 1
  rules.value.unshift({
    id,
    pool: payload.pool,
    method: payload.method,
    target: payload.target,
    cron: payload.cron,
    timeout: timeoutStr,
    retry: payload.retry,
    creator: '当前用户',
    updatedAt,
    status: '已停止'
  })
  ElMessage.success('创建成功')
  page.value = 1
}

function onBatchExport() {
  ElMessage.info(`批量导出 ${selection.value.length} 条（示例未实现）`)
}

function onBatchImport() {
  ElMessage.info('批量导入（示例未实现）')
}
</script>

<template>
  <div class="page">
    <el-card shadow="never" class="search-card">
      <div class="toolbar">
        <div class="left">
          <el-input
            v-model="keyword"
            placeholder="关键字搜索 (拨测池/目标对象/创建人)"
            clearable
            style="width: 320px"
          />
          <span class="filter-label">拨测方式:</span>
          <el-select v-model="methodFilter" placeholder="全部" style="width: 120px" clearable>
            <el-option v-for="opt in methodOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
          </el-select>
          <span class="filter-label">状态:</span>
          <el-select v-model="statusFilter" placeholder="全部" style="width: 120px" clearable>
            <el-option v-for="opt in statusFilterOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
          </el-select>
          <el-button type="primary" @click="onSearch">
            <el-icon><Plus /></el-icon>
            查询
          </el-button>
        </div>
        <div class="right">
          <el-button type="primary" @click="onCreate">
            <el-icon><Plus /></el-icon>
            创建
          </el-button>
          <el-button @click="onBatchExport">
            <el-icon><Download /></el-icon>
            批量导出
          </el-button>
          <el-button @click="onBatchImport">
            <el-icon><Upload /></el-icon>
            批量导入
          </el-button>
        </div>
      </div>
    </el-card>

    <el-card shadow="never" class="table-card">
      <el-table :data="pageData" stripe style="width: 100%" @selection-change="onSelectionChange">
        <el-table-column type="selection" width="48" />
        <el-table-column prop="pool" label="拨测池" min-width="120" sortable />
        <el-table-column label="拨测方式" min-width="110">
          <template #default="{ row }">
            <el-tag :type="methodTagType(row.method)" size="small">{{ row.method }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="target" label="目标对象" min-width="180" sortable show-overflow-tooltip />
        <el-table-column prop="cron" label="拨测频率" min-width="130" sortable />
        <el-table-column prop="timeout" label="超时时间" min-width="100" sortable />
        <el-table-column prop="retry" label="重试次数" min-width="90" sortable />
        <el-table-column prop="creator" label="创建人" min-width="90" />
        <el-table-column prop="updatedAt" label="最后修改时间" min-width="120" sortable />
        <el-table-column label="状态" min-width="90" align="center">
          <template #default="{ row }">
            <span class="status" :class="row.status === '运行中' ? 'running' : 'stopped'">{{ row.status }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" min-width="340" fixed="right" align="center">
          <template #default="{ row }">
            <el-space :size="6">
              <el-button
                v-if="row.status === '已停止'"
                size="small"
                type="primary"
                @click="onStart(row)"
              >
                启动
              </el-button>
              <el-button
                v-if="row.status === '运行中'"
                size="small"
                type="danger"
                @click="onStop(row)"
              >
                停止
              </el-button>
              <el-button size="small" @click="onEdit(row)">
                <el-icon><EditPen /></el-icon>
                编辑
              </el-button>
              <el-button size="small" type="danger" plain @click="onDelete(row)">
                <el-icon><Delete /></el-icon>
                删除
              </el-button>
              <el-button size="small" @click="onExport(row)">
                <el-icon><Download /></el-icon>
                导出
              </el-button>
            </el-space>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination">
        <div class="total">共 {{ total }} 条</div>
        <el-pagination
          v-model:current-page="page"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[5, 10, 20, 50]"
          layout="sizes, prev, pager, next, jumper"
          background
        />
      </div>
    </el-card>

    <CreateRuleDialog v-model="createVisible" :pool-options="poolOptions" @submit="onCreateSubmit" />
  </div>
</template>

<style scoped>
.page {
  padding: 16px;
}

.search-card {
  margin-bottom: 12px;
}

.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
}

.left,
.right {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.filter-label {
  color: var(--el-text-color-regular);
  font-size: 14px;
  white-space: nowrap;
}

.toolbar .el-icon {
  margin-right: 4px;
}

.table-card {
  padding-bottom: 4px;
}

.status {
  font-weight: 600;
}

.status.running {
  color: var(--el-color-success);
}

.status.stopped {
  color: var(--el-text-color-secondary);
}

.pagination {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 12px;
}

.total {
  color: var(--el-text-color-regular);
  font-size: 13px;
}
</style>
