<script setup>
import { computed, reactive, watch, ref } from 'vue'
import { Search } from '@element-plus/icons-vue'

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  options: { type: Array, default: () => [] } // [{ ip, name }]
})

const emit = defineEmits(['update:modelValue', 'submit'])

const formRef = ref(null)
const form = reactive({
  ips: []
})

const rules = {
  ips: [{ type: 'array', required: true, message: '请选择物理机IP', trigger: 'change' }]
}

const selectOptions = computed(() =>
  (props.options ?? []).map((o) => ({
    value: o.ip,
    label: `${o.ip}（${o.name}）`,
    ip: o.ip,
    name: o.name
  }))
)

function close() {
  emit('update:modelValue', false)
}

function reset() {
  form.ips = []
  formRef?.clearValidate?.()
}

watch(
  () => props.modelValue,
  (v) => {
    if (v) reset()
  }
)

async function onConfirm() {
  const ok = await formRef?.validate?.().catch(() => false)
  if (!ok) return
  emit('submit', form.ips.slice())
  close()
}
</script>

<template>
  <el-dialog
    :model-value="modelValue"
    title="批量添加拨测源"
    width="980px"
    align-center
    :close-on-click-modal="false"
    @update:model-value="(v) => emit('update:modelValue', v)"
  >
    <el-form ref="formRef" :model="form" :rules="rules" label-position="top" class="dlg-form">
      <el-form-item label="物理机IP" prop="ips" required>
        <el-select
          v-model="form.ips"
          multiple
          filterable
          collapse-tags
          collapse-tags-tooltip
          clearable
          :suffix-icon="Search"
          placeholder="请选择物理机IP"
          size="large"
          style="width: 100%"
        >
          <el-option v-for="opt in selectOptions" :key="opt.value" :label="opt.label" :value="opt.value">
            <div class="opt">
              <span class="ip">{{ opt.ip }}</span>
              <span class="name">（{{ opt.name }}）</span>
            </div>
          </el-option>
        </el-select>
      </el-form-item>
    </el-form>

    <template #footer>
      <div class="dlg-footer">
        <el-button size="large" @click="close">取 消</el-button>
        <el-button size="large" type="primary" @click="onConfirm">确 定</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<style scoped>
.dlg-form {
  padding: 6px 8px 0;
}

.dlg-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}

.opt {
  display: flex;
  gap: 6px;
  align-items: center;
}

.ip {
  font-weight: 700;
  color: var(--el-text-color-primary);
}

.name {
  font-weight: 600;
  color: var(--el-text-color-primary);
}
</style>

